

    <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">
      <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
      </div>

      <div class="table-responsive">
        <table class="table table-striped table-sm">
          <thead>
            <tr>
              <th>Book ID</th>
              <th><?php echo $idbuku?></th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <th>Title</th>
              <th><?php echo $judul?></th>
            </tr>
            <tr>
            	<td>Author</td>
            	<td><?php echo $pengarang?></td>
            </tr>
            <tr>
            	<td>Publisher</td>
            	<td><?php echo $penerbit?></td>
            </tr>
            <tr>
            	<td>Category ID</td>
            	<td><?php echo $idkategori ?></td>
            </tr>
            <tr>
            	<td>Synopsis</td>
            	<td><?php echo $sinopsis ?></td>
            </tr>
            <tr>
            	<td>Year of Release</td>
	            <td><?php echo $thnterbit ?></td>
            </tr>
            <tr>
            	<td>Book Cover</td>
            	<td><?php echo "<img src=".$img.">" ?></td> 
            </tr>                   
          </tbody>
        </table>
      </div>
      
    </main>
  